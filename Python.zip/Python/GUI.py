# Importar librerías
from tkinter import ttk
from tkinter import *
import serial
from PIL import Image, ImageTk
import time as tm
import sqlite3
import datetime

# Configuración del puerto serial
ser = serial.Serial('COM3', 9600)
datos_guardar = []

# Reescribir datos
def enviar_dato(dato):
    ser.write(dato.encode())

# Función para enviar "1" al presionar el primer botón
def enviar_uno():
    enviar_dato("1")
    tm.sleep(1)
    data = ser.readline().decode()
    lista = data.split(",")
    datos_guardar.append(float(lista[0]))
    datos_guardar.append(int(lista[1]))
    datos.set(f"Frecuencia: {lista[0]} --- SpO2: {lista[1]}%")

# Función para enviar "2" al presionar el segundo botón
def enviar_dos():
    enviar_dato("2")
    tm.sleep(1)
    data = ser.readline().decode()
    datos_guardar.append(float(data))
    datos.set(f"Temperatura: {data} °C")

# Guardar datos en la base de datos
def Guardar():
    con = sqlite3.connect('Pacientes2.db')
    Paciente =[nombreVar.get(),
               int(edadVar.get()),
               sexoVar.get(),
               cedeulaVar.get(),
               telefonoVar.get(),
               datos_guardar[2],
               datos_guardar[0],
               datos_guardar[1],
               datetime.datetime.now()]
    con.cursor().execute("""INSERT INTO Pacientes (Nombre,Edad,Sexo,Cedula,Telefono,Temperatura,
    Frecuencia,Oxigenacion,Fecha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", tuple(Paciente))
    con.commit()
    con.close()
    print("Guardado exitoso")
    datos = []

# Obtener datos registrados a partir del teléfono del paciente atendido (Login)
def Fill():
    con = sqlite3.connect('Pacientes2.db')
    cursor = con.cursor()
    cursor.execute(f"""select Nombre, Edad, Sexo, Cedula, Temperatura, Frecuencia, 
    Oxigenacion from Pacientes where Telefono = {telefonoVar.get()}""")
    lista = cursor.fetchall()
    nombreVar.set(lista[0][0])
    edadVar.set(lista[0][1])
    sexoVar.set(lista[0][2])
    cedeulaVar.set(lista[0][3])
    datos.set(f"temp/frec/oxi: {lista[0][4]}/{lista[0][5]}/{lista[0][6]} ")
    con.close()

# Crear una ventana de visualización
root = Tk()
root.title("Registro de Datos")
root.geometry("600x450")  
root.resizable(0,0)
root.config(bg = "blue")

# Cargar imagen de fondo
background_image = Image.open("Monitor/BMO.png")
background_photo = ImageTk.PhotoImage(background_image)
frame = Frame(root)
frame.config(background = "lightblue")
frame.pack(pady = 20)

# Crea un Canvas que cubra toda la ventana
canvas = Canvas(frame, width=200, height=400)
canvas.grid(row=0, column=0, rowspan=4, padx=20)
canvas.create_image(0, 0, anchor=NW, image=background_photo)

# Botones
button1 = Button(frame, text="Frecuencia", command=enviar_uno, width=10, height=2, background="lightgreen")
button2 = Button(frame, text="Temperatura", command=enviar_dos, width=10, height=2, background="lightgreen")
button3 = Button(frame, text="Guardar", command=lambda:Guardar(),width=10, height=2, background="lightgreen")
button4 = Button(frame, text="Fill", command=lambda:Fill(),width=10, height=2, background="lightgreen")

button1.grid(row=0, column=1, padx=10, pady=40)
button2.grid(row=0, column=2, padx=10, pady=40)
button3.grid(row=0, column=3, padx=10, pady=40)
button4.place(x=340,y=350)

# Campos de texto
nombreText = Label(frame,text="Nombre:",bg="lightblue")
nombreText.place(x=250,y=140)
nombreVar = StringVar()
nombre = Entry(frame,textvariable=nombreVar,font=("Times",12))
nombre.place(x=315,y=140)

edadText = Label(frame,text="Edad:",bg="lightblue")
edadText.place(x=250,y=165)
edadVar = StringVar()
edad = Entry(frame,textvariable=edadVar,font=("Times",12))
edad.place(x=315,y=165)

sexoText = Label(frame,text="Sexo:",bg="lightblue")
sexoText.place(x=250,y=190)
sexoVar = StringVar()
sexo = ttk.Combobox(frame,textvariable=sexoVar,font=("Times",11),values=["Masculino","Femenino","No Binario"])
sexo.place(x=315,y=190)

cedeulaText = Label(frame,text="Cedula:",bg="lightblue")
cedeulaText.place(x=250,y=215)
cedeulaVar = StringVar()
cedeula = Entry(frame,textvariable=cedeulaVar,font=("Times",12))
cedeula.place(x=315,y=215)

telefonoText = Label(frame,text="Telefono:",bg="lightblue")
telefonoText.place(x=250,y=240)
telefonoVar = StringVar()
telefono = Entry(frame,textvariable=telefonoVar, font=("Times",12))
telefono.place(x=315,y=240)

sensor = Label(frame,text="Lecturas Recibidas de los Sensores",bg="lightblue")
sensor.place(x=280,y=280)
datos = StringVar()
entry = Entry(frame,textvariable=datos,font=("Times",15),width=30)
entry.place(x=230,y=310)

root.mainloop()