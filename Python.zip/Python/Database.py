import sqlite3 # Importar librería sqlite3

# Esto conectará a la base de datos llamada "Pacientes2.db"
con = sqlite3.connect('Pacientes2.db')
cursor = con.cursor()
cursor.execute('''CREATE TABLE Pacientes (
                ID INTEGER AUTO_INCREMENT PRIMARY KEY,
                Nombre VARCHAR(75),
                Edad INTEGER,
                Sexo VARCHAR(20),
                Cedula VARCHAR(20),
                Telefono VARCHAR(20),
                Temperatura FLOAT,
                Frecuencia FLOAT,
                Oxigenacion INTEGER,
                Fecha DATE
              )''')
con.close()